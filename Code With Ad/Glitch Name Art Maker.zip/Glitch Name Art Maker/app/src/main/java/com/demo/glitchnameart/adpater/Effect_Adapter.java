package com.demo.glitchnameart.adpater;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.demo.glitchnameart.R;

import com.demo.glitchnameart.MainActivity;
import com.demo.glitchnameart.imageview.RoundedImageView;


public class Effect_Adapter extends RecyclerView.Adapter<Effect_Adapter.MyViewHolder> {
    Context mContext;
    int pos = 0;
    String[] sc;

    public Effect_Adapter(Context context, String[] sc) {
        this.mContext = context;
        this.sc = sc;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.effect_adapter, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        int w = this.mContext.getResources().getDisplayMetrics().widthPixels;
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((w * 185) / 1080, (w * 185) / 1080);
        holder.top_img.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((w * 180) / 1080, (w * 180) / 1080);
        params1.addRule(13);
        holder.img.setLayoutParams(params1);
        holder.img.setCornerRadius((w * 10) / 1080);
        Glide.with(this.mContext).load(Uri.parse("file:///android_asset/sc/" + this.sc[position])).into(holder.img);
        if (this.pos == position) {
            holder.top_img.setVisibility(View.VISIBLE);
        } else {
            holder.top_img.setVisibility(View.INVISIBLE);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ((MainActivity) Effect_Adapter.this.mContext).setColor(position);
                Effect_Adapter.this.pos = position;
                Effect_Adapter.this.notifyDataSetChanged();
                holder.top_img.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.sc.length;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public RoundedImageView img;
        public ImageView top_img;
        RelativeLayout main_lay;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.main_lay = (RelativeLayout) itemView.findViewById(R.id.main_lay);
            this.img = (RoundedImageView) itemView.findViewById(R.id.img);
            this.top_img = (ImageView) itemView.findViewById(R.id.top_img);
        }
    }
}
