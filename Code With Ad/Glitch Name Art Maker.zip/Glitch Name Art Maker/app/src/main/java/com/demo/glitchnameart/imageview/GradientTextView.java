package com.demo.glitchnameart.imageview;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.widget.TextView;

import com.demo.glitchnameart.R;


public class GradientTextView extends TextView {
    int c1;
    int c2;
    AttributeSet mAttributeSet;
    Context mContext;
    int mDefStyleAttr;
    Shader shader;

    public GradientTextView(Context context) {
        super(context);
    }

    public GradientTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.mAttributeSet = attrs;
        if (!isInEditMode()) {
            createShader(context, attrs, 0);
        }
    }

    public GradientTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        this.mAttributeSet = attrs;
        this.mDefStyleAttr = defStyleAttr;
        if (!isInEditMode()) {
            createShader(context, attrs, defStyleAttr);
        }
    }

    @TargetApi(21)
    public GradientTextView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.mContext = context;
        this.mAttributeSet = attrs;
        this.mDefStyleAttr = defStyleAttr;
        if (!isInEditMode()) {
            createShader(context, attrs, defStyleAttr);
        }
    }

    public void createShader(Context context, AttributeSet attrs, int defStyleAttr) {


        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.GradientTextView, defStyleAttr, 0);
        try {
            this.c1 = a.getInt(R.styleable.GradientTextView_gradientStart, 0);
            this.c2 = a.getInt(R.styleable.GradientTextView_gradientEnd, 0);
            this.shader = new LinearGradient(0.0f, 0.0f, 0.0f, getTextSize(), new int[]{this.c1, this.c2}, new float[]{0.0f, 1.0f}, Shader.TileMode.CLAMP);
            getPaint().setShader(this.shader);
        } finally {
            a.recycle();
        }
    }

    public void setColors(int c1, int c2) {
        this.c1 = c1;
        this.c2 = c2;
        if (!isInEditMode()) {
            createShader(this.mContext, this.mAttributeSet, this.mDefStyleAttr);
        }
    }
}
