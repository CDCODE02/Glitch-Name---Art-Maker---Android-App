package com.demo.glitchnameart;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import java.io.File;


public class Save_Show extends Activity {
    ImageView back;
    ImageView bd;
    Bitmap bit;
    ImageView delete;
    Typeface font;
    int h;
    ImageView img;
    String path;
    ImageView share;
    TextView title;
    int w;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.save_show);



        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd((RelativeLayout) findViewById(R.id.banner), this);
        adAdmob.FullscreenAd_Counter(this);

        getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.h = getResources().getDisplayMetrics().heightPixels;
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            builder.detectFileUriExposure();
        }
        this.font = Typeface.createFromAsset(getAssets(), "A_HELR45W.ttf");
        this.delete = (ImageView) findViewById(R.id.delete);
        this.share = (ImageView) findViewById(R.id.share);
        this.bd = (ImageView) findViewById(R.id.bd);
        this.img = (ImageView) findViewById(R.id.img);
        this.back = (ImageView) findViewById(R.id.back);
        this.title = (TextView) findViewById(R.id.title);
        this.title.setTypeface(this.font);
        this.path = getIntent().getStringExtra("path");
        File f = new File(this.path);
        this.bit = BitmapFactory.decodeFile(f.getAbsolutePath());
        this.img.setImageBitmap(this.bit);
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Save_Show.this.onBackPressed();
            }
        });
        this.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                AlertDialog.Builder alert = new AlertDialog.Builder(Save_Show.this);
                alert.setTitle("Confirm Delete !");
                alert.setMessage("Are you sure to delete Image??");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        File file = new File(Save_Show.this.path);
                        if (file.exists()) {
                            file.delete();
                        }
                        Toast.makeText(Save_Show.this, "Delete Succussfully", Toast.LENGTH_SHORT).show();
                        Save_Show.this.onBackPressed();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
            }
        });
        this.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent share = new Intent("android.intent.action.SEND");
                share.setType("*/*");
                File f2 = new File(Save_Show.this.path);

                 Uri data = FileProvider.getUriForFile(Save_Show.this, getPackageName() + ".provider", f2);

                share.putExtra("android.intent.extra.STREAM", data);
                Save_Show.this.startActivity(Intent.createChooser(share, "Share Image"));
            }
        });
        setLayout();
    }

    void setLayout() {
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 102) / 1080, (this.h * 102) / 1920);
        params1.addRule(15);
        params1.setMargins((this.w * 30) / 1080, 0, 0, 0);
        this.back.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.w * 272) / 1080, (this.h * 70) / 1920);
        params2.addRule(13);
        this.share.setLayoutParams(params2);
        this.delete.setLayoutParams(params2);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams((this.w * 15) / 1080, (this.h * 95) / 1920);
        params3.gravity = 16;
        this.bd.setLayoutParams(params3);
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }


}
