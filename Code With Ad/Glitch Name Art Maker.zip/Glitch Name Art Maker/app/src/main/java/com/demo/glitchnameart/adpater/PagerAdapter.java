package com.demo.glitchnameart.adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.demo.glitchnameart.R;

import java.util.ArrayList;


public class PagerAdapter extends androidx.viewpager.widget.PagerAdapter {
    ArrayList<String> images;
    LayoutInflater layoutInflater;
    Context mContext;

    public PagerAdapter(Context context, ArrayList<String> images) {
        this.mContext = context;
        this.images = images;
        this.layoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override
    public int getCount() {
        return this.images.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((RelativeLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = this.layoutInflater.inflate(R.layout.page_adapter, container, false);
        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);
        String url = this.images.get(position);
        Glide.with(this.mContext).load(url).crossFade().diskCacheStrategy(DiskCacheStrategy.ALL).error((int) R.drawable.photo_bg).into(imageView);
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout) object);
    }
}
