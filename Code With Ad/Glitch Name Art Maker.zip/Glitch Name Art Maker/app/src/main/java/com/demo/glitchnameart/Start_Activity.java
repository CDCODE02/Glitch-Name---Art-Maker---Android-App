package com.demo.glitchnameart;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;


public class Start_Activity extends Activity {
    ImageView create_name;
    int h;

    ImageView mywork;
    String[] permission = {"android.permission.WRITE_EXTERNAL_STORAGE"};
    ImageView pp;
    int w;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);

        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd((RelativeLayout) findViewById(R.id.banner), this);
        adAdmob.FullscreenAd_Counter(this);



        if (Build.VERSION.SDK_INT >= 33) {

        } else {
            goToMain();
        }

        getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.h = getResources().getDisplayMetrics().heightPixels;
        this.create_name = (ImageView) findViewById(R.id.create_name);
        this.mywork = (ImageView) findViewById(R.id.mywork);
        this.pp = (ImageView) findViewById(R.id.pp);
        this.create_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Start_Activity.this.startActivity(new Intent(Start_Activity.this.getApplicationContext(), MainActivity.class));
            }
        });
        this.mywork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Start_Activity.this.startActivity(new Intent(Start_Activity.this.getApplicationContext(), MyWork.class));
            }
        });
        this.pp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Start_Activity.this.startActivity(new Intent(Start_Activity.this.getApplicationContext(), Policy.class));
            }
        });
        AllowPermission();
        setLayout();
    }

    void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 676) / 1080, (this.h * 395) / 1920);
        params.addRule(2, R.id.mywork);
        this.create_name.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 676) / 1080, (this.h * 395) / 1920);
        params1.addRule(12);
        params1.addRule(11);
        params1.setMargins(0, -((this.h * 80) / 1920), 0, (this.h * 50) / 1920);
        this.mywork.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.w * 261) / 1080, (this.h * 398) / 1920);
        params2.addRule(15);
        params2.addRule(11);
        this.pp.setLayoutParams(params2);
    }

    void AllowPermission() {
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (Build.VERSION.SDK_INT >= 23 && grantResults[0] != 0) {
            requestPermissions(this.permission, 100);
        }
    }


    public void goToMain() {
        if (Build.VERSION.SDK_INT >= 23 && (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0)) {
            requestPermissions(this.permission, 100);
        }
    }

}
