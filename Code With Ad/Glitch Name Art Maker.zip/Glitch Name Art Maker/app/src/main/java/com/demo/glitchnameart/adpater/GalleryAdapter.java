package com.demo.glitchnameart.adpater;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.demo.glitchnameart.R;

import java.util.ArrayList;

import com.demo.glitchnameart.imageview.RoundedImageView;


public class GalleryAdapter extends BaseAdapter {
    Typeface font;
    LayoutInflater inflater;
    private ArrayList<String> image;
    private Context mContext;

    public GalleryAdapter(Context context, ArrayList<String> myimage) {
        this.inflater = null;
        this.mContext = context;
        this.image = myimage;
        this.font = Typeface.createFromAsset(this.mContext.getAssets(), "A_HELR45W.ttf");
        this.inflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.image = myimage;
    }

    @Override
    public int getCount() {
        return this.image.size();
    }

    @Override
    public Object getItem(int position) {
        return Integer.valueOf(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null) {
            vi = this.inflater.inflate(R.layout.gallery_adapter, (ViewGroup) null);
        }
        RoundedImageView img = (RoundedImageView) vi.findViewById(R.id.image);
        RelativeLayout main_lay = (RelativeLayout) vi.findViewById(R.id.main_lay);
        TextView name = (TextView) vi.findViewById(R.id.name);
        String url = this.image.get(position);
        String[] str = url.split("_");
        name.setText(str[str.length - 1].split(".jpg")[0]);
        name.setTypeface(this.font);
        int w = this.mContext.getResources().getDisplayMetrics().widthPixels;
        int h = this.mContext.getResources().getDisplayMetrics().heightPixels;
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((w * 383) / 1080, (h * 381) / 1920);
        params1.addRule(14);
        img.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((w * 518) / 1080, (h * 518) / 1920);
        params2.addRule(13);
        params2.setMargins(0, (h * 40) / 1920, 0, 0);
        main_lay.setLayoutParams(params2);
        img.setCornerRadius((w * 15) / 1080);
        Glide.with(this.mContext).load(url).crossFade().into(img);
        return vi;
    }
}
