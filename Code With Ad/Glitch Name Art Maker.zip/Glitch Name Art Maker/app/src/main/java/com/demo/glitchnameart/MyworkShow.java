package com.demo.glitchnameart;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.viewpager.widget.ViewPager;

import java.io.File;

import com.demo.glitchnameart.adpater.PagerAdapter;


public class MyworkShow extends Activity {
    ImageView back;
    ImageView bd;
    int current_item;
    ImageView delete;
    Typeface font;
    int h;
    PagerAdapter myCustomPagerAdapter;
    ImageView share;
    TextView title;
    ViewPager viewPager;
    int w;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myworkshow);

        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd((RelativeLayout) findViewById(R.id.banner), this);
        adAdmob.FullscreenAd_Counter(this);

        getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.h = getResources().getDisplayMetrics().heightPixels;
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (Build.VERSION.SDK_INT >= 18) {
            builder.detectFileUriExposure();
        }
        this.delete = (ImageView) findViewById(R.id.delete);
        this.share = (ImageView) findViewById(R.id.share);
        this.back = (ImageView) findViewById(R.id.back);
        this.bd = (ImageView) findViewById(R.id.bd);
        this.viewPager = (ViewPager) findViewById(R.id.viewPager);
        this.myCustomPagerAdapter = new PagerAdapter(this, MyWork.photo);
        this.viewPager.setAdapter(this.myCustomPagerAdapter);
        this.viewPager.setCurrentItem(MyWork.pos);
        this.title = (TextView) findViewById(R.id.title);
        this.font = Typeface.createFromAsset(getAssets(), "A_HELR45W.ttf");
        this.title.setTypeface(this.font);
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MyworkShow.this.onBackPressed();
            }
        });
        this.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                MyworkShow.this.current_item = MyworkShow.this.viewPager.getCurrentItem();
                AlertDialog.Builder alert = new AlertDialog.Builder(MyworkShow.this);
                alert.setTitle("Confirm Delete !");
                alert.setMessage("Are you sure to delete Image??");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        File file = new File(MyWork.photo.get(MyworkShow.this.current_item));
                        if (file.exists()) {
                            file.delete();
                        }
                        Toast.makeText(MyworkShow.this, "Delete Succussfully", Toast.LENGTH_SHORT).show();
                        if (Build.VERSION.SDK_INT < 19) {
                            MyworkShow.this.sendBroadcast(new Intent("android.intent.action.MEDIA_MOUNTED", Uri.parse("file://" + Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES))));
                        } else {
                            MediaScannerConnection.scanFile(MyworkShow.this, new String[]{file.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                @Override
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });
                        }
                        MyWork.photo.remove(MyworkShow.this.current_item);
                        MyworkShow.this.setViewPager(MyworkShow.this.current_item);
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
            }
        });
        this.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                MyworkShow.this.current_item = MyworkShow.this.viewPager.getCurrentItem();
                Intent share = new Intent("android.intent.action.SEND");
                share.setType("*/*");
                File f = new File(MyWork.photo.get(MyworkShow.this.current_item));


                Uri data = FileProvider.getUriForFile(MyworkShow.this, getPackageName() + ".provider", f);

                share.putExtra("android.intent.extra.STREAM", data);
                MyworkShow.this.startActivity(Intent.createChooser(share, "Share Image"));
            }
        });
        setLayout();
    }

    void setViewPager(int current_item) {
        this.myCustomPagerAdapter = new PagerAdapter(this, MyWork.photo);
        this.viewPager.setAdapter(this.myCustomPagerAdapter);
        if (MyWork.photo.size() == 0) {
            onBackPressed();
        } else if (current_item > MyWork.photo.size() - 1) {
            this.viewPager.setCurrentItem(current_item - 1);
        } else if (current_item == 0) {
            this.viewPager.setCurrentItem(0);
        } else {
            this.viewPager.setCurrentItem(current_item);
        }
    }

    void setLayout() {
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 102) / 1080, (this.h * 102) / 1920);
        params1.addRule(15);
        params1.setMargins((this.w * 30) / 1080, 0, 0, 0);
        this.back.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.w * 272) / 1080, (this.h * 70) / 1920);
        params2.addRule(13);
        this.share.setLayoutParams(params2);
        this.delete.setLayoutParams(params2);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams((this.w * 15) / 1080, (this.h * 95) / 1920);
        params3.gravity = 16;
        this.bd.setLayoutParams(params3);
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
    }


}
