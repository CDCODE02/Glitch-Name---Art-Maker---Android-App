package com.demo.glitchnameart;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

import com.demo.glitchnameart.adpater.Effect_Adapter;
import com.demo.glitchnameart.adpater.Sticker_Adapter;
import com.demo.glitchnameart.adpater.Text_Style_Adapter;
import com.demo.glitchnameart.holocolorpicker.ColorPicker;
import com.demo.glitchnameart.holocolorpicker.OpacityBar;
import com.demo.glitchnameart.holocolorpicker.SVBar;
import com.demo.glitchnameart.imageview.RoundedImageView;
import com.demo.glitchnameart.sticker.StickerView;
import com.demo.glitchnameart.touch.MultiTouchListener;


public class MainActivity extends Activity {
    Effect_Adapter adapter;
    Text_Style_Adapter adapter2;
    Sticker_Adapter adapter3;
    ImageView back;
    ImageView bg;
    Bitmap bitmap;
    int blueValue;
    View div;
    ImageView done;
    ImageView edit_name;
    RecyclerView effect_list;
    Typeface font;
    FrameLayout frame;
    ImageView gradient;
    int greenValue;
    int h;
    RecyclerView.LayoutManager lm;
    RecyclerView.LayoutManager lm2;
    RecyclerView.LayoutManager lm3;
    StickerView mCurrentView;
    File mGalleryFolder;
    Uri mImageUri;
    int pixel;
    int redValue;
    RelativeLayout save_lay;
    String[] scs;
    String send1;
    boolean set_gradient;
    ImageView setting;
    SeekBar size_seek;
    boolean start_c;
    String[] stick;
    ImageView sticker;
    RecyclerView sticker_list;
    String[] style;
    int temp_fc;
    int temp_sc;
    TextView text;
    ImageView text_bg;
    ImageView text_size;
    ImageView text_style;
    RecyclerView text_style_list;
    TextView title;
    int w;
    int x;
    int y;
    boolean first_time = true;
    int text_color = -8323328;
    int shadow_color = 0xffff0000;
    int sx = 0;
    int sy = 0;
    int sp = 0;
    ArrayList<View> mViews = new ArrayList<>();
    int fc = -4096;
    int sc = -16711936;
    private OpacityBar opacityBar;
    private ColorPicker picker;
    private SVBar svBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.FullscreenAd_Counter(this);

        getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.h = getResources().getDisplayMetrics().heightPixels;
        this.fc = getResources().getColor(R.color.first_color);
        this.sc = getResources().getColor(R.color.second_color);
        this.font = Typeface.createFromAsset(getAssets(), "A_HELR45W.ttf");
        this.first_time = true;
        this.mGalleryFolder = createFolders();
        this.bg = (ImageView) findViewById(R.id.bg);
        this.div = findViewById(R.id.div);
        this.edit_name = (ImageView) findViewById(R.id.edit_name);
        this.text_style = (ImageView) findViewById(R.id.text_style);
        this.text_size = (ImageView) findViewById(R.id.text_size);
        this.text_bg = (ImageView) findViewById(R.id.text_bg);
        this.setting = (ImageView) findViewById(R.id.setting);
        this.sticker = (ImageView) findViewById(R.id.sticker);
        this.gradient = (ImageView) findViewById(R.id.gradient);
        this.back = (ImageView) findViewById(R.id.back);
        this.done = (ImageView) findViewById(R.id.done);
        this.save_lay = (RelativeLayout) findViewById(R.id.save_lay);
        this.size_seek = (SeekBar) findViewById(R.id.size_seek);
        this.size_seek.setMax(110);
        this.size_seek.setProgress(55);
        this.text = (TextView) findViewById(R.id.text);
        this.title = (TextView) findViewById(R.id.title);
        this.text.setTypeface(this.font);
        this.title.setTypeface(this.font);
        this.effect_list = (RecyclerView) findViewById(R.id.effect_list);
        this.text_style_list = (RecyclerView) findViewById(R.id.text_style_list);
        this.sticker_list = (RecyclerView) findViewById(R.id.sticker_list);
        this.frame = (FrameLayout) findViewById(R.id.frame);
        this.text.setOnTouchListener(new MultiTouchListener());
        try {
            this.stick = getAssets().list("sticker");
            this.style = getAssets().list("fonts");
            this.scs = getAssets().list("sc");
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.adapter = new Effect_Adapter(this, this.scs);
        this.effect_list.setAdapter(this.adapter);
        this.adapter2 = new Text_Style_Adapter(this, this.style);
        this.text_style_list.setAdapter(this.adapter2);
        this.adapter3 = new Sticker_Adapter(this, this.stick);
        this.sticker_list.setAdapter(this.adapter3);
        this.lm = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.lm2 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.lm3 = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        this.effect_list.setLayoutManager(this.lm);
        this.text_style_list.setLayoutManager(this.lm2);
        this.sticker_list.setLayoutManager(this.lm3);
        this.size_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float f = progress + 10;
                MainActivity.this.text.setTextSize(f);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (MainActivity.this.set_gradient) {
                            MainActivity.this.setGradient(MainActivity.this.text, MainActivity.this.fc, MainActivity.this.sc);
                        }
                    }
                }, 100L);
            }
        });
        this.edit_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.dialog();
            }
        });
        this.text_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.effect_list.setVisibility(View.GONE);
                MainActivity.this.text_style_list.setVisibility(View.GONE);
                MainActivity.this.sticker_list.setVisibility(View.GONE);
                if (MainActivity.this.size_seek.getVisibility() == View.GONE) {
                    MainActivity.this.size_seek.setVisibility(View.VISIBLE);
                    MainActivity.this.div.setVisibility(View.VISIBLE);
                    return;
                }
                MainActivity.this.size_seek.setVisibility(View.GONE);
                MainActivity.this.div.setVisibility(View.INVISIBLE);
            }
        });
        this.text_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.size_seek.setVisibility(View.GONE);
                MainActivity.this.text_style_list.setVisibility(View.GONE);
                MainActivity.this.sticker_list.setVisibility(View.GONE);
                if (MainActivity.this.effect_list.getVisibility() == View.GONE) {
                    MainActivity.this.effect_list.setVisibility(View.VISIBLE);
                    MainActivity.this.div.setVisibility(View.VISIBLE);
                    return;
                }
                MainActivity.this.div.setVisibility(View.INVISIBLE);
                MainActivity.this.effect_list.setVisibility(View.GONE);
            }
        });
        this.text_style.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.size_seek.setVisibility(View.GONE);
                MainActivity.this.effect_list.setVisibility(View.GONE);
                MainActivity.this.sticker_list.setVisibility(View.GONE);
                if (MainActivity.this.text_style_list.getVisibility() == View.GONE) {
                    MainActivity.this.div.setVisibility(View.VISIBLE);
                    MainActivity.this.text_style_list.setVisibility(View.VISIBLE);
                    return;
                }
                MainActivity.this.div.setVisibility(View.INVISIBLE);
                MainActivity.this.text_style_list.setVisibility(View.GONE);
            }
        });
        this.setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.size_seek.setVisibility(View.GONE);
                MainActivity.this.effect_list.setVisibility(View.GONE);
                MainActivity.this.text_style_list.setVisibility(View.GONE);
                MainActivity.this.sticker_list.setVisibility(View.GONE);
                MainActivity.this.div.setVisibility(View.INVISIBLE);
                MainActivity.this.setting_dialog();
            }
        });
        this.sticker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.size_seek.setVisibility(View.GONE);
                MainActivity.this.effect_list.setVisibility(View.GONE);
                MainActivity.this.text_style_list.setVisibility(View.GONE);
                if (MainActivity.this.sticker_list.getVisibility() == View.GONE) {
                    MainActivity.this.sticker_list.setVisibility(View.VISIBLE);
                    MainActivity.this.div.setVisibility(View.VISIBLE);
                    return;
                }
                MainActivity.this.div.setVisibility(View.INVISIBLE);
                MainActivity.this.sticker_list.setVisibility(View.GONE);
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.onBackPressed();
            }
        });
        this.save_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.this.mCurrentView != null) {
                    MainActivity.this.mCurrentView.setInEdit(false);
                }
            }
        });
        this.done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity.this.save_lay.performClick();
                if (MainActivity.this.saveImage()) {
                    Toast.makeText(MainActivity.this.getApplicationContext(), "Image Saved in " + MainActivity.this.getResources().getString(R.string.app_name), Toast.LENGTH_SHORT).show();
                    Intent newIntent3 = new Intent(MainActivity.this, Save_Show.class);
                    newIntent3.putExtra("path", MainActivity.this.send1);
                    MainActivity.this.startActivity(newIntent3);
                    MainActivity.this.finish();
                    return;
                }
                Toast.makeText(MainActivity.this.getApplicationContext(), "Error in Image Saved ", Toast.LENGTH_SHORT).show();
            }
        });
        this.gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.sel_gradient_dialog();
            }
        });
        try {
            InputStream is = getAssets().open("sc/" + this.scs[0]);
            Drawable d = Drawable.createFromStream(is, null);
            this.bg.setImageDrawable(d);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.setGradient(MainActivity.this.text, MainActivity.this.fc, MainActivity.this.sc);
            }
        }, 500L);
        setStyle(Typeface.createFromAsset(getAssets(), "fonts/0CFGlitchCity-Regular.ttf"));
        this.set_gradient = true;
        this.text.setShadowLayer(this.sp, this.sx, this.sy, this.shadow_color);
        setLayout();
        dialog();
    }

    void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(this.w, this.w);
        params.setMargins(0, (this.h * 10) / 1920, 0, 0);
        this.save_lay.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 102) / 1080, (this.h * 102) / 1920);
        params1.addRule(13);
        this.back.setLayoutParams(params1);
        this.done.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.w * 240) / 1080, (this.h * 151) / 1920);
        params2.addRule(13);
        this.edit_name.setLayoutParams(params2);
        this.text_style.setLayoutParams(params2);
        this.text_size.setLayoutParams(params2);
        this.text_bg.setLayoutParams(params2);
        this.setting.setLayoutParams(params2);
        this.sticker.setLayoutParams(params2);
        this.gradient.setLayoutParams(params2);
        Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.drawable.thumb);
        int sw = (this.w * thumb.getHeight()) / 1080;
        this.size_seek.setThumb(new BitmapDrawable(getResources(), Bitmap.createScaledBitmap(thumb, sw, sw, true)));
    }

    public void setColor(int position) {
        try {
            InputStream is = getAssets().open("sc/" + this.scs[position]);
            Drawable d = Drawable.createFromStream(is, null);
            this.bg.setImageDrawable(d);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    public void setStyle(Typeface ty) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (MainActivity.this.set_gradient) {
                    MainActivity.this.setGradient(MainActivity.this.text, MainActivity.this.fc, MainActivity.this.sc);
                }
            }
        }, 500L);
        this.text.setTypeface(ty);
    }

    void dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.custom_dialog1);
        LinearLayout top_lay = (LinearLayout) dialog.findViewById(R.id.top_lay);
        final EditText input = (EditText) dialog.findViewById(R.id.entertext);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        ImageView cancel = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView submit = (ImageView) dialog.findViewById(R.id.submit);
        dialog.getWindow().setSoftInputMode(5);
        title.setTypeface(this.font);
        input.setTypeface(this.font);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 904) / 1080, (this.h * 393) / 1920);
        top_lay.setLayoutParams(params);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams((this.w * 222) / 1080, (this.h * 97) / 1920);
        params1.setMargins(0, 0, (this.w * 40) / 1080, 0);
        submit.setLayoutParams(params1);
        cancel.setLayoutParams(params1);
        String s = this.text.getText().toString();
        try {
            StringBuilder sb = new StringBuilder(s);
            if (s.endsWith(" ")) {
                sb.deleteCharAt(s.length() - 1);
            }
            if (s.startsWith(" ")) {
                sb.deleteCharAt(0);
            }
            s = sb.toString();
        } catch (Exception e) {
            e.toString();
        }
        input.setText(s);
        input.setSelection(input.getText().length());
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String srt = input.getEditableText().toString();
                if (srt.equals("")) {
                    input.setError("Enter Value");
                    return;
                }
                MainActivity.this.text.setText(" " + srt + " ");
                dialog.dismiss();
                MainActivity.this.first_time = false;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (MainActivity.this.set_gradient) {
                            MainActivity.this.setGradient(MainActivity.this.text, MainActivity.this.fc, MainActivity.this.sc);
                        }
                    }
                }, 100L);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.this.first_time) {
                    MainActivity.this.onBackPressed();
                }
                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog2) {
                if (MainActivity.this.first_time) {
                    MainActivity.this.onBackPressed();
                }
            }
        });
    }


    public boolean saveImage() {
        File file = null;
        if (this.mGalleryFolder != null && this.mGalleryFolder.exists()) {
            file = new File(this.mGalleryFolder, "img_" + System.currentTimeMillis() + "_" + this.text.getText().toString() + ".jpg");
        }
        try {
            Bitmap selectedImage = getFrameBitmap();
            this.mImageUri = Uri.parse("file://" + file.getPath());
            this.send1 = file.getPath().toString();
            FileOutputStream fos = new FileOutputStream(file);
            selectedImage.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
            MediaScannerConnection.scanFile(this, new String[]{file.getAbsolutePath()}, new String[]{"image/jpeg"}, null);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Bitmap getFrameBitmap() {
        this.save_lay.postInvalidate();
        this.save_lay.setDrawingCacheEnabled(true);
        this.save_lay.buildDrawingCache();
        Bitmap bm = Bitmap.createBitmap(this.save_lay.getDrawingCache());
        this.save_lay.destroyDrawingCache();
        return bm;
    }

    private File createFolders() {
        File baseDir;

            baseDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        File aviaryFolder = new File(baseDir, getResources().getString(R.string.app_name));
        return (aviaryFolder.exists() || aviaryFolder.mkdirs()) ? aviaryFolder : Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
    }

    void text_color_dialog(final TextView txt) {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        LinearLayout mainLay = (LinearLayout) dialog.findViewById(R.id.mainLay);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 900) / 1080, (this.h * 1310) / 1920);
        mainLay.setLayoutParams(params);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        ImageView cancel = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView submit = (ImageView) dialog.findViewById(R.id.ok);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 258) / 1080, (this.h * 113) / 1920);
        params1.addRule(13);
        cancel.setLayoutParams(params1);
        submit.setLayoutParams(params1);
        title.setTypeface(this.font);
        title.setText("Text Color");
        this.picker = (ColorPicker) dialog.findViewById(R.id.picker);
        this.svBar = (SVBar) dialog.findViewById(R.id.svbar);
        this.opacityBar = (OpacityBar) dialog.findViewById(R.id.opacitybar);
        LinearLayout.LayoutParams params4 = new LinearLayout.LayoutParams((this.w * 650) / 1080, (this.h * 650) / 1920);
        params4.gravity = 17;
        this.picker.setLayoutParams(params4);
        this.picker.addSVBar(this.svBar);
        this.picker.addOpacityBar(this.opacityBar);
        this.picker.setOldCenterColor(this.text_color);
        this.picker.setColor(this.text_color);
        this.svBar.setColor(this.text_color);
        this.opacityBar.setColor(this.text_color);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.text_color = MainActivity.this.picker.getColor();
                MainActivity.this.text.setTextColor(MainActivity.this.text_color);
                txt.setTextColor(MainActivity.this.text_color);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    void text_shadow_color_dialog(final TextView txt) {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        LinearLayout mainLay = (LinearLayout) dialog.findViewById(R.id.mainLay);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 900) / 1080, (this.h * 1310) / 1920);
        mainLay.setLayoutParams(params);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        ImageView cancel = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView submit = (ImageView) dialog.findViewById(R.id.ok);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 258) / 1080, (this.h * 113) / 1920);
        params1.addRule(13);
        cancel.setLayoutParams(params1);
        submit.setLayoutParams(params1);
        title.setTypeface(this.font);
        title.setText("Shadow Color");
        this.picker = (ColorPicker) dialog.findViewById(R.id.picker);
        this.svBar = (SVBar) dialog.findViewById(R.id.svbar);
        this.opacityBar = (OpacityBar) dialog.findViewById(R.id.opacitybar);
        LinearLayout.LayoutParams params4 = new LinearLayout.LayoutParams((this.w * 650) / 1080, (this.h * 650) / 1920);
        params4.gravity = 17;
        this.picker.setLayoutParams(params4);
        this.picker.addSVBar(this.svBar);
        this.picker.addOpacityBar(this.opacityBar);
        this.picker.setOldCenterColor(this.shadow_color);
        this.picker.setColor(this.shadow_color);
        this.svBar.setColor(this.shadow_color);
        this.opacityBar.setColor(this.shadow_color);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.shadow_color = MainActivity.this.picker.getColor();
                MainActivity.this.text.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
                txt.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    void setting_dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.setting_popup);
        LinearLayout mainLay = (LinearLayout) dialog.findViewById(R.id.mainLay);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 900) / 1080, (this.h * 1310) / 1920);
        mainLay.setLayoutParams(params);
        RelativeLayout t_lay = (RelativeLayout) dialog.findViewById(R.id.t_lay);
        t_lay.setPadding((this.w * 8) / 1080, 0, (this.w * 8) / 1080, 0);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        title.setTypeface(this.font);
        ImageView font_color = (ImageView) dialog.findViewById(R.id.font_color);
        ImageView done = (ImageView) dialog.findViewById(R.id.done);
        ImageView color = (ImageView) dialog.findViewById(R.id.shadow_color);
        final TextView temp_text = (TextView) dialog.findViewById(R.id.temp_text);
        TextView txt_shadow = (TextView) dialog.findViewById(R.id.txt_shadow);
        TextView txt_x = (TextView) dialog.findViewById(R.id.txt_x);
        TextView txt_y = (TextView) dialog.findViewById(R.id.txt_y);
        temp_text.setTypeface(this.font);
        txt_shadow.setTypeface(this.font);
        txt_x.setTypeface(this.font);
        txt_y.setTypeface(this.font);
        temp_text.setShadowLayer(this.sp, this.sx, this.sy, this.shadow_color);
        temp_text.setTextColor(this.text.getCurrentTextColor());
        temp_text.setText(this.text.getText().toString());
        SeekBar shadow = (SeekBar) dialog.findViewById(R.id.shadow);
        SeekBar x = (SeekBar) dialog.findViewById(R.id.x);
        SeekBar y = (SeekBar) dialog.findViewById(R.id.y);
        shadow.setMax(25);
        x.setMax(20);
        y.setMax(20);
        shadow.setProgress(this.sp);
        x.setProgress(this.sx + 10);
        y.setProgress(this.sy + 10);
        Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.drawable.thumb);
        int sw = (this.w * thumb.getWidth()) / 1080;
        Bitmap thumb2 = Bitmap.createScaledBitmap(thumb, sw, sw, true);
        x.setThumb(new BitmapDrawable(getResources(), thumb2));
        y.setThumb(new BitmapDrawable(getResources(), thumb2));
        shadow.setThumb(new BitmapDrawable(getResources(), thumb2));
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 102) / 1080, (this.h * 102) / 1920);
        params1.addRule(15);
        params1.addRule(11);
        params1.setMargins(0, 0, (this.w * 30) / 1080, 0);
        done.setLayoutParams(params1);
        RelativeLayout.LayoutParams params4 = new RelativeLayout.LayoutParams((this.w * 398) / 1080, (this.h * 164) / 1920);
        params4.addRule(13);
        color.setLayoutParams(params4);
        font_color.setLayoutParams(params4);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.set_gradient = false;
                MainActivity.this.text.setLayerType(View.LAYER_TYPE_NONE, null);
                MainActivity.this.text.getPaint().setShader(null);
                MainActivity.this.text.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
                dialog.dismiss();
            }
        });
        color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity.this.text_shadow_color_dialog(temp_text);
            }
        });
        font_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity.this.text_color_dialog(temp_text);
            }
        });
        y.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                MainActivity.this.sy = progress - 10;
                temp_text.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
            }
        });
        x.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                MainActivity.this.sx = progress - 10;
                temp_text.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
            }
        });
        shadow.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                MainActivity.this.sp = seekBar.getProgress();
                temp_text.setShadowLayer(MainActivity.this.sp, MainActivity.this.sx, MainActivity.this.sy, MainActivity.this.shadow_color);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            }
        });
        dialog.show();
    }

    private void addStickerView(Bitmap stickBit) {
        final StickerView stickerView = new StickerView(this);
        stickerView.SetStickBitmap(stickBit);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            @Override
            public void onDeleteClick() {
                MainActivity.this.mViews.remove(stickerView);
                MainActivity.this.frame.removeView(stickerView);
            }

            @Override
            public void onEdit(StickerView stickerView2) {
                MainActivity.this.mCurrentView.setInEdit(false);
                MainActivity.this.mCurrentView = stickerView2;
                MainActivity.this.mCurrentView.setInEdit(true);
            }

            @Override
            public void onTop(StickerView stickerView2) {
                int position = MainActivity.this.mViews.indexOf(stickerView2);
                if (position != MainActivity.this.mViews.size() - 1) {
                    StickerView stickerTemp = (StickerView) MainActivity.this.mViews.remove(position);
                    MainActivity.this.mViews.add(MainActivity.this.mViews.size(), stickerTemp);
                }
            }
        });
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(-1, -1);
        this.frame.addView(stickerView, lp);
        this.mViews.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        if (this.mCurrentView != null) {
            this.mCurrentView.setInEdit(false);
        }
        this.mCurrentView = stickerView;
        stickerView.setInEdit(true);
    }

    public void setStricker(int pos) {
        try {
            InputStream inputStream = getAssets().open("sticker/" + this.stick[pos]);
            addStickerView(BitmapFactory.decodeStream(inputStream));
        } catch (Exception e) {
            e.toString();
        }
    }

    void setGradient(TextView txt, int fc, int sc) {
        Shader textShader = new LinearGradient(0.0f, 0.0f, 0.0f, txt.getHeight() / txt.getLineCount(), new int[]{fc, sc}, new float[]{0.0f, 1.0f}, Shader.TileMode.REPEAT);
        txt.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        txt.getPaint().setShader(textShader);
    }

    void sel_gradient_dialog() {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.gradient_pop);
        LinearLayout mainLay = (LinearLayout) dialog.findViewById(R.id.mainlay);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.w * 968) / 1080, (this.h * 1149) / 1920);
        mainLay.setLayoutParams(params);
        RelativeLayout t_lay = (RelativeLayout) dialog.findViewById(R.id.t_lay);
        t_lay.setPadding((this.w * 8) / 1080, 0, (this.w * 8) / 1080, 0);
        TextView title = (TextView) dialog.findViewById(R.id.title);
        ImageView cancel = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView submit = (ImageView) dialog.findViewById(R.id.ok);
        final TextView temp_text = (TextView) dialog.findViewById(R.id.temp_text);
        TextView start_color_txt = (TextView) dialog.findViewById(R.id.start_color_txt);
        TextView end_color_txt = (TextView) dialog.findViewById(R.id.end_color_txt);
        final ImageView start_sel = (ImageView) dialog.findViewById(R.id.start_sel);
        final ImageView end_sel = (ImageView) dialog.findViewById(R.id.end_sel);
        final RoundedImageView end_color = (RoundedImageView) dialog.findViewById(R.id.end_color);
        final RoundedImageView start_color = (RoundedImageView) dialog.findViewById(R.id.start_color);
        final ImageView colorlay = (ImageView) dialog.findViewById(R.id.colorlay);
        final RelativeLayout lay = (RelativeLayout) dialog.findViewById(R.id.lay);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.bitmap = BitmapFactory.decodeResource(MainActivity.this.getResources(), R.drawable.color_pallet);
                MainActivity.this.bitmap = MainActivity.this.bitmapResize(MainActivity.this.bitmap, lay);
                colorlay.setImageBitmap(MainActivity.this.bitmap);
            }
        }, 500L);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 258) / 1080, (this.h * 113) / 1920);
        params1.addRule(13);
        cancel.setLayoutParams(params1);
        submit.setLayoutParams(params1);
        title.setTypeface(this.font);
        start_color_txt.setTypeface(this.font);
        end_color_txt.setTypeface(this.font);
        start_color.setColorFilter(this.fc);
        end_color.setColorFilter(this.sc);
        end_color.setCornerRadius((this.w * 90) / 1080);
        start_color.setCornerRadius((this.w * 90) / 1080);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.setGradient(temp_text, MainActivity.this.fc, MainActivity.this.sc);
                MainActivity.this.temp_fc = MainActivity.this.fc;
                MainActivity.this.temp_sc = MainActivity.this.sc;
            }
        }, 100L);
        this.start_c = true;
        start_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.start_c = true;
                start_sel.setVisibility(View.VISIBLE);
                end_sel.setVisibility(View.GONE);
            }
        });
        end_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.start_c = false;
                start_sel.setVisibility(View.GONE);
                end_sel.setVisibility(View.VISIBLE);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.fc = MainActivity.this.temp_fc;
                MainActivity.this.sc = MainActivity.this.temp_sc;
                MainActivity.this.setGradient(MainActivity.this.text, MainActivity.this.fc, MainActivity.this.sc);
                MainActivity.this.set_gradient = true;
                dialog.dismiss();
            }
        });
        colorlay.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getActionMasked();
                switch (action) {
                    case 0:
                        try {
                            MainActivity.this.x = (int) event.getX();
                            MainActivity.this.y = (int) event.getY();
                            MainActivity.this.pixel = MainActivity.this.bitmap.getPixel(MainActivity.this.x, MainActivity.this.y);
                            MainActivity.this.redValue = Color.red(MainActivity.this.pixel);
                            MainActivity.this.blueValue = Color.blue(MainActivity.this.pixel);
                            MainActivity.this.greenValue = Color.green(MainActivity.this.pixel);
                            break;
                        } catch (Exception e) {
                            e.toString();
                            break;
                        }
                    case 2:
                        try {
                            MainActivity.this.x = (int) event.getX();
                            MainActivity.this.y = (int) event.getY();
                            MainActivity.this.pixel = MainActivity.this.bitmap.getPixel(MainActivity.this.x, MainActivity.this.y);
                            MainActivity.this.redValue = Color.red(MainActivity.this.pixel);
                            MainActivity.this.blueValue = Color.blue(MainActivity.this.pixel);
                            MainActivity.this.greenValue = Color.green(MainActivity.this.pixel);
                            break;
                        } catch (Exception e2) {
                            e2.toString();
                            break;
                        }
                }
                try {
                    String hex = String.format("#%02x%02x%02x%02x", 255, Integer.valueOf(MainActivity.this.redValue), Integer.valueOf(MainActivity.this.greenValue), Integer.valueOf(MainActivity.this.blueValue));
                    if (MainActivity.this.start_c) {
                        MainActivity.this.temp_fc = Color.parseColor(hex);
                        start_color.setColorFilter(MainActivity.this.temp_fc);
                    } else {
                        MainActivity.this.temp_sc = Color.parseColor(hex);
                        end_color.setColorFilter(MainActivity.this.temp_sc);
                    }
                    MainActivity.this.setGradient(temp_text, MainActivity.this.temp_fc, MainActivity.this.temp_sc);
                } catch (Exception e3) {
                    e3.toString();
                }
                return true;
            }
        });
        dialog.show();
    }

    public Bitmap bitmapResize(Bitmap bit, View v) {
        int newheight;
        int newwidth;
        int layoutwidth = v.getWidth();
        int layoutheight = v.getHeight();
        int imagewidth = bit.getWidth();
        int imageheight = bit.getHeight();
        if (imagewidth >= imageheight) {
            newwidth = layoutwidth;
            newheight = (newwidth * imageheight) / imagewidth;
            if (newheight > layoutheight) {
                newwidth = (layoutheight * newwidth) / newheight;
                newheight = layoutheight;
            }
        } else {
            newheight = layoutheight;
            newwidth = (newheight * imagewidth) / imageheight;
            if (newwidth > layoutwidth) {
                newheight = (newheight * layoutwidth) / newwidth;
                newwidth = layoutwidth;
            }
        }
        Bitmap b56 = Bitmap.createScaledBitmap(bit, newwidth, newheight, true);
        return b56;
    }

}
