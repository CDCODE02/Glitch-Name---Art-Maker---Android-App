package com.demo.glitchnameart;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;

import com.demo.glitchnameart.adpater.GalleryAdapter;


public class MyWork extends Activity {
    public static ArrayList<String> photo = new ArrayList<>();
    public static int pos;
    GalleryAdapter adapter;
    ImageView back;
    String folder_name;
    Typeface font;
    GridView gridview;
    int h;
    File[] listFile = null;
    TextView title;
    int w;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mywork);


        AdAdmob adAdmob = new AdAdmob( this);
        adAdmob.BannerAd((RelativeLayout) findViewById(R.id.banner), this);
        adAdmob.FullscreenAd_Counter(this);

        getWindow().addFlags(1024);
        this.w = getResources().getDisplayMetrics().widthPixels;
        this.h = getResources().getDisplayMetrics().heightPixels;
        this.font = Typeface.createFromAsset(getAssets(), "A_HELR45W.ttf");
        this.folder_name = getResources().getString(R.string.app_name);
        this.gridview = (GridView) findViewById(R.id.gridview);
        this.back = (ImageView) findViewById(R.id.back);
        this.title = (TextView) findViewById(R.id.title);
        this.title.setTypeface(this.font);
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyWork.this.onBackPressed();
            }
        });
        photo.clear();
        getFromSdcard();
        this.adapter = new GalleryAdapter(this, photo);
        this.gridview.setAdapter((ListAdapter) this.adapter);
        this.gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MyWork.pos = position;
                MyWork.this.startActivity(new Intent(MyWork.this.getApplicationContext(), MyworkShow.class));
            }
        });
        this.adapter.notifyDataSetChanged();
        setLayout();
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.adapter.notifyDataSetChanged();
    }

    public void getFromSdcard() {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), this.folder_name);
        if (file.isDirectory()) {
            this.listFile = file.listFiles();
            for (int i = this.listFile.length - 1; i >= 0; i--) {
                photo.add(this.listFile[i].getAbsolutePath());
            }
        }
    }

    void setLayout() {
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.w * 102) / 1080, (this.h * 102) / 1920);
        params1.addRule(15);
        params1.setMargins((this.w * 30) / 1080, 0, 0, 0);
        this.back.setLayoutParams(params1);
    }


}
