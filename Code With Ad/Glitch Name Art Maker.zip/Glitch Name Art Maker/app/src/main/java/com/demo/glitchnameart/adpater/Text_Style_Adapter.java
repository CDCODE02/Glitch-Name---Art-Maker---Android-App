package com.demo.glitchnameart.adpater;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.demo.glitchnameart.R;

import com.demo.glitchnameart.MainActivity;


public class Text_Style_Adapter extends RecyclerView.Adapter<Text_Style_Adapter.MyViewHolder> {
    public static String[] text_styles;
    Context mContext;
    int pos = 0;

    public Text_Style_Adapter(Context context, String[] mystyles) {
        text_styles = mystyles;
        this.mContext = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_style_adapter, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final Typeface custom_font = Typeface.createFromAsset(this.mContext.getAssets(), "fonts/" + text_styles[position]);
        try {
            holder.txt.setTypeface(custom_font);
        } catch (Exception e) {
            e.toString();
        }
        if (this.pos == position) {
            holder.txt.setTextColor(Color.parseColor("#35A1B6"));
        } else {
            holder.txt.setTextColor(-16777216);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Text_Style_Adapter.this.pos = position;
                holder.txt.setTextColor(Color.parseColor("#35A1B6"));
                ((MainActivity) Text_Style_Adapter.this.mContext).setStyle(custom_font);
                Text_Style_Adapter.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return text_styles.length;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txt;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.txt = (TextView) itemView.findViewById(R.id.txt);
        }
    }
}
